# Third-party references and notices

## iOS 27 Design System

- Project: https://github.com/seunghan91/ios27-design-system
- License stated by upstream: MIT
- Use in this prototype: visual and interaction direction (layered glass surfaces, spacing hierarchy, readable controls, dark/light material concepts) is used as a design reference. No upstream source files, icons, Apple assets, or component package files are bundled in this prototype.
- The upstream project is an independent web implementation and is not affiliated with or endorsed by Apple.

## Simutrans

- Project: https://github.com/simutrans/simutrans
- License: Artistic License 1.0
- Use in this prototype: reference for transport-network and logistics gameplay only. No Simutrans source code, paksets, graphics, music, or fonts are bundled in this initial prototype.
- Before any source reuse, follow `docs/SIMUTRANS_POLICY.md` and include the complete applicable license and per-file change notices.

## 47国志 / AMIX

- Game: https://amix-design.com/tl/tool-g-47kokushi/
- License / asset information: https://amix-design.com/tl/tool-g-47kokushi/license.html
- Use in this prototype: high-level gameplay inspiration only (regional selection, monthly actions, development and diplomacy loops). No game code, screen artwork, music, sound effects, fonts, or proprietary game data are copied.
- Upstream's listed audio assets are licensed from Audiostock. The game page also identifies separate licenses for its fonts, three.js library, and source datasets. Those assets are not bundled here.

## Game data and map

The current prefecture positions, population-scale values, industry indices, resource indices, and city blocks are prototype values created for gameplay balance. The strategic map is schematic, not a reproduction of official administrative boundaries. No real-world boundary, elevation, rail, or population dataset is bundled yet.
