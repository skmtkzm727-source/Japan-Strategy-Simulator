# Automated smoke tests

Run from the project root with Node.js 20 or later:

```bash
npm test
npm run check
```

The current automated suite covers:

- 47 prefecture records and 47 independent city maps
- initial Aichi city network, electricity balance and logistics capacity
- isolation between separate prefecture city saves
- starting a road network from a city gate and connecting facilities
- technology-gated rail, battery and logistics buildings
- preventing demolition that would isolate a facility
- national monthly settlement and action-point recovery
- save/load round trip and migration from v1 single-city saves
- research unlocks for higher-capacity transport

Full visual browser QA on multiple physical devices is still outstanding.
