import { prefectures, buildings, technologies } from './data.js';
import {
  createNewGame, loadGame, saveGame, getSelectedPrefecture, getSelectedCity, getCityStats, getNationalCityStats,
  investInRegion, holdRegionalForum, placeBuilding, demolishTile, setTaxRate,
  startResearch, signAgreement, strengthenResilience, advanceMonth
} from './simulation.js';

let state = loadGame() || createNewGame();
let toastTimer = null;
const app = document.querySelector('#app');
const main = document.querySelector('#mainContent');
const topMetrics = document.querySelector('#topMetrics');

const fmt = (n) => Math.round(n).toLocaleString('ja-JP');
const money = (n) => `${fmt(n)}億円`;
const pct = (n) => `${Math.round(n)}%`;
const monthLabel = () => `${state.date.year}年 ${state.date.month}月`;

function toast(message, kind = 'info') {
  const stack = document.querySelector('#toastStack');
  const el = document.createElement('div');
  el.className = `toast ${kind}`;
  el.textContent = message;
  stack.append(el);
  window.setTimeout(() => el.remove(), 3200);
}

function updateTopbar() {
  topMetrics.innerHTML = `
    <div class="metric-chip"><span>国家予算</span><strong>${money(state.funds)}</strong></div>
    <div class="metric-chip"><span>GDP</span><strong>${state.gdp.toFixed(1)}兆円</strong></div>
    <div class="metric-chip"><span>人口</span><strong>${(state.population / 100).toFixed(2)}億人</strong></div>
    <div class="metric-chip"><span>内閣支持率</span><strong>${pct(state.approval)}</strong></div>`;
  document.querySelector('#dateLabel').textContent = monthLabel();
  document.querySelector('#apLabel').textContent = `${state.actionPoints} / 4`;
  document.querySelector('#apPips').innerHTML = Array.from({ length: 4 }, (_, i) => `<i class="${i >= state.actionPoints ? 'off' : ''}"></i>`).join('');
  document.querySelectorAll('[data-view]').forEach(btn => btn.classList.toggle('active', btn.dataset.view === state.activeView));
}

function heading(eyebrow, title, subtitle, right = '') {
  return `<div class="page-heading"><div><div class="eyebrow">${eyebrow}</div><h1 class="page-title">${title}</h1><p class="page-subtitle">${subtitle}</p></div><div class="heading-actions">${right}</div></div>`;
}

function mapMarkup() {
  const selected = state.selectedPrefecture;
  const markers = state.prefectures.map(pref => {
    const level = pref.support >= 70 ? 'high' : pref.support >= 48 ? 'mid' : 'low';
    const isSelected = pref.id === selected;
    const radius = isSelected ? 9 : 6.5;
    return `<g class="pref-marker ${level} ${isSelected ? 'selected' : ''}" data-pref="${pref.id}" tabindex="0" role="button" aria-label="${pref.name}を選択">
      <circle class="halo" cx="${pref.x}" cy="${pref.y}" r="${radius + 6}" />
      <circle class="point" cx="${pref.x}" cy="${pref.y}" r="${radius}" />
      <text x="${pref.x + 9}" y="${pref.y + 3}">${pref.name}</text>
    </g>`;
  }).join('');
  return `<svg class="japan-map" viewBox="0 0 900 740" role="img" aria-label="日本列島の模式戦略マップ">
    <defs>
      <linearGradient id="landFill" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#547b9b"/><stop offset=".55" stop-color="#31536f"/><stop offset="1" stop-color="#233c5b"/></linearGradient>
      <filter id="mapShadow" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="7"/></filter>
      <pattern id="seaGrid" width="40" height="40" patternUnits="userSpaceOnUse"><path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(126,165,205,.07)" stroke-width=".7"/></pattern>
    </defs>
    <rect width="900" height="740" fill="url(#seaGrid)"/>
    <path class="map-island" d="M 731,79 C 766,75 798,102 800,135 C 798,166 770,195 751,212 C 731,211 715,195 708,173 C 698,142 705,98 731,79 Z"/>
    <path class="map-island" d="M 691,235 C 723,239 752,267 758,296 C 756,326 735,350 728,377 C 722,405 719,433 695,453 C 676,468 670,496 648,520 C 627,539 611,529 597,510 C 583,493 568,485 548,484 C 528,482 517,466 501,458 C 484,452 470,480 449,496 C 430,506 414,490 394,497 C 374,506 358,522 338,527 C 321,529 313,514 297,526 C 280,540 266,539 256,525 C 244,506 254,486 271,475 C 287,466 302,454 317,451 C 339,446 348,425 367,420 C 386,411 400,419 417,410 C 438,400 448,374 466,368 C 486,357 501,367 520,357 C 539,345 550,325 572,319 C 595,312 605,287 621,269 C 639,253 663,239 691,235 Z"/>
    <path class="map-island" d="M 398,574 C 421,567 451,575 461,590 C 465,606 448,620 431,629 C 409,635 390,624 380,608 C 378,592 384,582 398,574 Z"/>
    <path class="map-island" d="M 218,548 C 239,548 260,563 258,584 C 257,602 238,621 227,640 C 216,659 202,681 182,690 C 166,692 153,678 156,660 C 161,637 178,616 181,596 C 182,574 197,553 218,548 Z"/>
    <path class="map-island" d="M 69,665 C 86,659 104,667 111,679 C 111,694 98,706 80,709 C 64,706 55,692 59,679 C 60,673 64,668 69,665 Z"/>
    <path class="map-detail" d="M 250 240 C 390 315 480 315 660 220 M 190 390 C 340 360 480 390 650 430 M 170 590 C 300 510 435 565 565 600"/>
    <text class="map-label" x="753" y="225">HOKKAIDO</text><text class="map-label" x="652" y="555">HONSHU</text><text class="map-label" x="352" y="658">SHIKOKU</text><text class="map-label" x="131" y="715">KYUSHU</text>
    ${markers}
  </svg>`;
}

function eventRows() {
  return state.events.slice(0, 4).map(event => `<div class="event-row"><div class="event-date">${event.month}</div><div><strong><i class="event-kind ${event.kind}"></i>${event.title}</strong><p>${event.text}</p></div></div>`).join('');
}

function strategyView() {
  const pref = getSelectedPrefecture(state);
  const supportColor = pref.support >= 70 ? 'var(--ios27-color-accent-green)' : pref.support >= 48 ? 'var(--ios27-color-accent-amber)' : 'var(--ios27-color-accent-red)';
  const regionalCount = state.prefectures.filter(p => p.influence >= 60).length;
  return `${heading('NATIONAL COMMAND / 01', '国家戦略マップ', '47都道府県の経済・支持・地域影響を俯瞰し、国家プロジェクトを指示します。', '<span class="section-tag">日本列島 · 47地域</span>')}
    <div class="strategy-layout">
      <section class="panel map-panel">
        <div class="panel-header"><div><div class="panel-title">日本広域マップ</div><div class="panel-subtitle">都道府県を選択して地域政策を実行</div></div><span class="section-tag">STRATEGIC VIEW</span></div>
        <div class="map-legend"><span><i class="legend-dot"></i>支持 70以上</span><span><i class="legend-dot mid"></i>支持 48–69</span><span><i class="legend-dot low"></i>支持 47以下</span></div>
        ${mapMarkup()}
        <div class="region-info"><div><strong>全国の地域支持</strong><br/><span>各地域の影響力・協力度合い</span></div><div class="region-count"><strong>${regionalCount} / 47 地域</strong><br/><span>影響力 60以上</span></div></div>
        <div class="map-footer"><span>模式マップ · 地理境界の正確な再現ではありません</span><span>選択：${pref.name}</span></div>
      </section>
      <aside class="panel detail-panel">
        <div class="panel-header"><div><div class="panel-title">地域インテリジェンス</div><div class="panel-subtitle">SELECTED PREFECTURE</div></div><span class="section-tag">${pref.region}</span></div>
        <div class="detail-top"><div><div class="pref-name">${pref.name}</div><div class="pref-region">${pref.region}ブロック · 地域行政区</div></div><div class="support-ring" style="--ring:${pref.support}%"><strong>${Math.round(pref.support)}%</strong></div></div>
        <div class="detail-stats">
          <div class="detail-stat"><span>人口規模（ゲーム値）</span><strong>${fmt(pref.population)}万人</strong></div>
          <div class="detail-stat"><span>産業指数</span><strong>${pref.industry} / 100</strong></div>
          <div class="detail-stat"><span>資源ポテンシャル</span><strong>${pref.resource} / 10</strong></div>
          <div class="detail-stat"><span>国政への影響力</span><strong>${Math.round(pref.influence)}%</strong></div>
        </div>
        <div class="detail-actions">
          <button class="button primary" data-action="invest">地域重点投資 <small>260億円 · 行動力 1</small></button>
          <button class="button" data-action="forum">地域協議会を開催 <small>90億円 · 行動力 1</small></button>
          <button class="button ghost" data-view="city">この地域の都市を開発 <small>都市マップへ ›</small></button>
        </div>
        <div class="mini-note">地域支持は政策の受け入れやすさを表すゲーム内指標です。現実の自治体・住民の評価や実統計を表すものではありません。</div>
      </aside>
    </div>
    <div class="bottom-grid">
      <section class="panel"><div class="panel-header"><div><div class="panel-title">国家イベントログ</div><div class="panel-subtitle">直近の政策・経済ニュース</div></div><span class="small-caps">LIVE FEED</span></div><div class="event-list">${eventRows()}</div></section>
      <section class="panel"><div class="panel-header"><div><div class="panel-title">国家能力サマリー</div><div class="panel-subtitle">MONTHLY STATUS</div></div></div><div class="stats-strip"><div class="tiny-stat"><span>研究ポイント</span><strong>${fmt(state.researchPoints)} RP</strong></div><div class="tiny-stat"><span>防衛力</span><strong>${state.defense} / 100</strong></div><div class="tiny-stat"><span>危機対応</span><strong>${state.readiness} / 100</strong></div></div></section>
    </div>`;
}

function cityView() {
  const city = getSelectedCity(state);
  const stats = getCityStats(state, city);
  const pref = getSelectedPrefecture(state);
  const selected = state.selectedBuild;
  const options = Object.entries(buildings).map(([id,b]) => { const locked = b.requires && !state.technologies.includes(b.requires); const requiredName = technologies.find(t => t.id === b.requires)?.name || '先行研究'; return `<button class="build-option ${selected === id ? 'selected' : ''} ${locked ? 'locked' : ''}" data-build="${id}" ${locked ? 'disabled' : ''}><span class="build-icon">${b.icon}</span><strong>${b.name}</strong><small>${locked ? `🔒 ${requiredName}` : money(b.cost)}</small></button>`; }).join('');
  const tileHtml = city.tiles.map((tile, index) => {
    const type = tile?.type || 'empty';
    const b = tile ? buildings[tile.type] : null;
    return `<button class="city-tile ${type}" data-tile="${index}" title="${b ? b.name : '空き区画'}" aria-label="${index + 1}番区画 ${b ? b.name : '空き'}">${b ? `<span class="tile-mark">${b.icon}</span>${tile.type !== 'road' ? `<span class="tile-name">${b.name}</span>` : ''}` : ''}</button>`;
  }).join('');
  const desc = selected === 'demolish' ? '施設を選ぶと撤去できます。建設費の一部を回収します。' : buildings[selected]?.desc || '';
  return `${heading('URBAN DEVELOPMENT / 02', '都市開発', `${pref.name}の都市区画を整備。道路をつなぎ、住宅・工場・交通施設を自由に配置します。`, '<span class="section-tag">CITY BUILDER</span>')}
    <div class="city-layout">
      <section class="panel city-board-panel">
        <div class="panel-header"><div><div class="panel-title">${pref.name}都市計画区画</div><div class="panel-subtitle">道路に隣接する空き区画へ施設を配置できます</div></div><div class="city-meta"><span>13 × 9 区画</span><span>·</span><span>${stats.count}施設</span></div></div>
        <div class="city-grid-wrap"><div class="city-grid">${tileHtml}</div></div>
        <div class="city-legend"><span><i style="background:#385a78"></i>住宅</span><span><i style="background:#665d53"></i>工場</span><span><i style="background:#385c65"></i>交通</span><span><i style="background:#6b623b"></i>電力</span><span><i style="background:#315d50"></i>公園</span><span><i style="background:#514c79"></i>研究</span></div>
        <div class="map-footer"><span>建設費はクリック時に即時精算</span><span>現在選択：${selected === 'demolish' ? '撤去' : buildings[selected]?.name}</span></div>
      </section>
      <aside class="panel build-panel">
        <div class="panel-header"><div><div class="panel-title">建設メニュー</div><div class="panel-subtitle">BUILD TOOL</div></div></div>
        <div class="build-list">${options}<button class="build-option ${selected === 'demolish' ? 'selected' : ''}" data-build="demolish"><span class="build-icon">⌫</span><strong>施設撤去</strong><small>20%返金</small></button></div>
        <div class="build-desc">${desc}</div>
        <div class="panel-header"><div><div class="panel-title">都市能力</div><div class="panel-subtitle">CITY OUTPUT</div></div></div>
        <div class="city-stats">
          <div class="city-stat"><span>追加人口</span><strong>+${fmt(stats.population)}人</strong></div>
          <div class="city-stat"><span>雇用</span><strong>${fmt(stats.jobs)}人</strong></div>
          <div class="city-stat"><span>工場の実効生産</span><strong>${stats.effectiveIndustry.toFixed(1)} / ${stats.industry}</strong></div>
          <div class="city-stat"><span>電力需給</span><strong>${stats.power} / ${stats.powerDemand} MW</strong></div>
          <div class="city-stat"><span>電力充足率</span><strong>${pct(stats.powerEfficiency * 100)}</strong></div>
          <div class="city-stat"><span>物流充足率</span><strong>${pct(stats.logisticsEfficiency * 100)}</strong></div>
          <div class="city-stat"><span>輸送容量</span><strong>${stats.logisticsCapacity.toFixed(1)}</strong></div>
          <div class="city-stat"><span>研究力 / 月</span><strong>+${stats.research}</strong></div>
          <div class="city-stat"><span>交通網</span><strong>道路 ${stats.roads} · 鉄道 ${stats.rails}</strong></div>
          <div class="city-stat"><span>施設維持費 / 月</span><strong>${money(stats.upkeep)}</strong></div>
        </div>
        <div class="build-desc" style="margin-top:0">接続済み施設 ${stats.connectedFacilities} / 孤立施設 ${stats.disconnectedFacilities}。工場の生産は道路・鉄道の接続、電力、物流容量によって変化します。研究を完了すると鉄道・港湾・倉庫・貨物空港などが解禁されます。</div>
      </aside>
    </div>`;
}

function economyView() {
  const stats = getNationalCityStats(state);
  const tradeBonus = state.partners.reduce((sum, p) => sum + Math.max(0, p.relation - 40) * 0.22, 0) * stats.logisticsEfficiency;
  const income = Math.round((280 + stats.tax + stats.effectiveIndustry * .48 + tradeBonus) * state.taxRate / 12);
  const upkeep = Math.round(88 + stats.upkeep + state.defense * .72);
  const taxFactor = state.taxRate / 12;
  const tradeBase = Math.round(tradeBonus);
  const incomeBars = [
    ['基礎税収', Math.round(280 * taxFactor)], ['都市施設', Math.round(stats.tax * taxFactor)], ['産業・輸出', Math.round(stats.effectiveIndustry * .48 * taxFactor)], ['交易', Math.round(tradeBase * taxFactor)]
  ];
  return `${heading('NATIONAL ECONOMY / 03', '経済・国家予算', '税制・公共投資・産業基盤を管理し、国家の財政と成長率のバランスを取ります。', '<span class="section-tag">FISCAL POLICY</span>')}
    <div class="economy-kpis">
      <div class="kpi-card"><span>国家予算</span><strong>${money(state.funds)}</strong><small>使用可能な国庫残高</small></div>
      <div class="kpi-card"><span>GDP</span><strong>${state.gdp.toFixed(1)}兆円</strong><small>前月比 +0.3%（ゲーム値）</small></div>
      <div class="kpi-card"><span>月次推定収入</span><strong>${money(income)}</strong><small>現在の税率で試算</small></div>
      <div class="kpi-card"><span>月次維持費</span><strong>${money(upkeep)}</strong><small>公共・施設・防衛関連</small></div>
    </div>
    <div class="content-grid">
      <section class="panel"><div class="panel-header"><div><div class="panel-title">税率・財政政策</div><div class="panel-subtitle">TAX RATE CONTROL</div></div><span class="section-tag">POLICY</span></div>
        <div class="tax-control"><div class="tax-head"><span>全国標準税率</span><strong id="taxValue">${state.taxRate}%</strong></div><input class="range" id="taxSlider" type="range" min="8" max="18" step="1" value="${state.taxRate}"/><div class="tax-head"><span>低負担・成長重視</span><span>財政健全化重視</span></div><p class="page-subtitle">税率を上げると月次収入が増えますが、高すぎる税率は内閣支持率を下げます。税率変更は即時反映されます。</p></div>
      </section>
      <section class="panel"><div class="panel-header"><div><div class="panel-title">収入構成</div><div class="panel-subtitle">MONTHLY REVENUE MIX</div></div></div><div class="bar-chart">${incomeBars.map(([label,value])=>`<div class="bar-row"><span>${label}</span><div class="bar-track"><div class="bar-fill" style="width:${Math.min(100,Math.max(2,value/3.8))}%"></div></div><strong>${fmt(value)}億</strong></div>`).join('')}</div></section>
      <section class="panel wide-panel"><div class="panel-header"><div><div class="panel-title">全国インフラ・生産能力</div><div class="panel-subtitle">ALL PREFECTURES · 47 CITIES</div></div></div><div class="stats-strip"><div class="tiny-stat"><span>工場の実効生産</span><strong>${fmt(stats.effectiveIndustry)} / ${fmt(stats.industry)}</strong></div><div class="tiny-stat"><span>電力充足率</span><strong>${pct(stats.powerEfficiency * 100)}</strong></div><div class="tiny-stat"><span>物流充足率</span><strong>${pct(stats.logisticsEfficiency * 100)}</strong></div><div class="tiny-stat"><span>雇用</span><strong>${fmt(stats.jobs)}人</strong></div></div></section>
      <section class="panel wide-panel"><div class="panel-header"><div><div class="panel-title">前月の財政実績</div><div class="panel-subtitle">LAST MONTH SETTLEMENT</div></div><span class="section-tag">${state.date.year}.${String(state.date.month).padStart(2,'0')}</span></div><div class="stats-strip"><div class="tiny-stat"><span>税収・交易収入</span><strong>${money(state.lastMonthly.income)}</strong></div><div class="tiny-stat"><span>施設・行政維持費</span><strong>${money(state.lastMonthly.upkeep)}</strong></div><div class="tiny-stat"><span>研究ポイント獲得</span><strong>+${state.lastMonthly.research} RP</strong></div><div class="tiny-stat"><span>実効生産指数</span><strong>${state.lastMonthly.production || 0}</strong></div></div></section>
    </div>`;
}

function researchView() {
  const completed = state.technologies.length;
  const cards = technologies.map(tech => {
    const done = state.technologies.includes(tech.id);
    const unlocked = tech.prereq.every(id => state.technologies.includes(id));
    const disabled = done || !unlocked || state.researchPoints < tech.cost || state.actionPoints < 1;
    const status = done ? '研究完了' : !unlocked ? '先行研究が必要' : `${tech.cost} RP必要`;
    return `<article class="panel tech-card ${done ? 'done' : ''} ${!unlocked ? 'locked' : ''}"><div class="tech-top"><span class="tech-group">${tech.group}</span><span class="tech-cost">${status}</span></div><h3>${tech.name}</h3><p>${tech.desc}</p><button class="button ${done ? 'ghost' : 'primary'}" data-research="${tech.id}" ${disabled ? 'disabled' : ''}>${done ? '✓ 完了' : '研究を開始'}</button></article>`;
  }).join('');
  return `${heading('RESEARCH & DEVELOPMENT / 04', '研究開発', '研究ポイントを消費して技術を解禁。産業・交通・エネルギーを現代から近未来へ進化させます。', `<span class="section-tag">${completed} / ${technologies.length} COMPLETE</span>`)}
    <section class="panel" style="margin-bottom:14px"><div class="panel-header"><div><div class="panel-title">国家研究予算</div><div class="panel-subtitle">研究ポイントは月末に自動獲得</div></div><strong style="font-size:20px;color:#cfe2ff">${fmt(state.researchPoints)} <small style="font-size:9px;color:#8498b3">RP</small></strong></div><div class="progress-track"><span style="width:${completed/technologies.length*100}%"></span></div></section>
    <div class="research-grid">${cards}</div>`;
}

function diplomacyView() {
  const cards = state.partners.map(partner => `<article class="panel partner-card"><div class="partner-meta"><span class="tech-group">${partner.focus}</span><strong>${partner.relation} / 100</strong></div><h3>${partner.name}</h3><p>${partner.detail}</p><div class="relation-track"><span style="width:${partner.relation}%"></span></div><button class="button primary" data-partner="${partner.id}" ${state.actionPoints < 1 || state.funds < 420 ? 'disabled' : ''}>協力協定を提案 <small>420億円 · 行動力 1</small></button></article>`).join('');
  return `${heading('DIPLOMACY & TRADE / 05', '外交・交易', '架空の国際パートナーと協力協定を結び、技術・資源・物流のネットワークを拡大します。', '<span class="section-tag">INTERNATIONAL</span>')}
    <div class="partner-grid">${cards}</div>
    <section class="panel" style="margin-top:14px"><div class="panel-header"><div><div class="panel-title">外交方針</div><div class="panel-subtitle">協定締結による効果</div></div></div><div class="stats-strip"><div class="tiny-stat"><span>交易収入</span><strong>関係値に応じて増加</strong></div><div class="tiny-stat"><span>技術連携</span><strong>共同研究イベント</strong></div><div class="tiny-stat"><span>資源供給</span><strong>輸入リスクを分散</strong></div></div></section>`;
}

function defenseView() {
  return `${heading('SECURITY & RESILIENCE / 06', '防衛・危機管理', '防衛力と国土強靱化を整え、災害・サイバー・物流寸断などの危機に備えます。', '<span class="section-tag">NATIONAL SECURITY</span>')}
    <div class="defense-layout">
      <section class="panel defense-meter"><div class="meter-heading"><span>総合防衛力</span><span>DEFENSE CAPABILITY</span></div><div class="meter-value">${state.defense}<span style="font-size:13px;color:#8496ae"> / 100</span></div><div class="meter-track"><span style="width:${state.defense}%"></span></div><div class="meter-note">重要インフラの保全、広域通信、災害時の初動対応を含む総合的なゲーム内指標です。</div></section>
      <section class="panel defense-meter"><div class="meter-heading"><span>危機対応準備度</span><span>READINESS</span></div><div class="meter-value">${state.readiness}<span style="font-size:13px;color:#8496ae"> / 100</span></div><div class="meter-track"><span style="width:${state.readiness}%"></span></div><div class="meter-note">自治体間連携・物資備蓄・交通網の代替性が高いほど、危機イベントの被害を抑えられます。</div></section>
    </div>
    <section class="panel defense-actions"><div class="panel-header" style="padding-left:0;padding-right:0"><div><div class="panel-title">国土強靱化・防衛演習</div><div class="panel-subtitle">INFRASTRUCTURE RESILIENCE PROGRAM</div></div><span class="section-tag">+4 DEF / +8 READY</span></div><p>自治体・交通事業者と合同で、重要施設の点検と広域対応訓練を実施します。防衛力と危機対応準備度が上昇します。</p><button class="button primary" data-action="resilience" ${state.actionPoints < 1 || state.funds < 340 ? 'disabled' : ''}>計画を実施 <small>340億円 · 行動力 1</small></button></section>`;
}

function render() {
  updateTopbar();
  const views = {
    strategy: strategyView,
    city: cityView,
    economy: economyView,
    research: researchView,
    diplomacy: diplomacyView,
    defense: defenseView
  };
  main.innerHTML = (views[state.activeView] || strategyView)();
}

function showModal(title, body, buttons = '<button class="button primary" data-action="close-modal">閉じる</button>') {
  const backdrop = document.querySelector('#modalBackdrop');
  document.querySelector('#modalContent').innerHTML = `<h2 id="modalTitle">${title}</h2>${body}<div class="modal-actions">${buttons}</div>`;
  backdrop.classList.remove('hidden');
}

function doAdvance() {
  const result = advanceMonth(state);
  render();
  toast(`${monthLabel()}へ進みました。収支 ${result.net >= 0 ? '+' : ''}${result.net}億円 · 研究 +${result.research} RP`, result.net >= 0 ? 'good' : 'warn');
}

function selectPrefecture(id) {
  if (!state.prefectures.some(p => p.id === id)) return;
  state.selectedPrefecture = id;
  render();
}

function handleClick(event) {
  const viewButton = event.target.closest('[data-view]');
  if (viewButton) {
    state.activeView = viewButton.dataset.view;
    render();
    return;
  }
  const prefMarker = event.target.closest('[data-pref]');
  if (prefMarker) { selectPrefecture(prefMarker.dataset.pref); return; }
  const buildButton = event.target.closest('[data-build]');
  if (buildButton) { state.selectedBuild = buildButton.dataset.build; render(); return; }
  const tileButton = event.target.closest('[data-tile]');
  if (tileButton) {
    const index = Number(tileButton.dataset.tile);
    const result = state.selectedBuild === 'demolish' ? demolishTile(state, index) : placeBuilding(state, index, state.selectedBuild);
    if (result.ok) { render(); toast(result.message, 'good'); }
    else toast(result.message, 'warn');
    return;
  }
  const researchButton = event.target.closest('[data-research]');
  if (researchButton) {
    const result = startResearch(state, researchButton.dataset.research);
    if (result.ok) { render(); toast(result.message, 'good'); }
    else toast(result.message, 'warn');
    return;
  }
  const partnerButton = event.target.closest('[data-partner]');
  if (partnerButton) {
    const result = signAgreement(state, partnerButton.dataset.partner);
    if (result.ok) { render(); toast(result.message, 'good'); }
    else toast(result.message, 'warn');
    return;
  }
  const action = event.target.closest('[data-action]')?.dataset.action;
  if (!action) return;
  switch (action) {
    case 'advance': doAdvance(); break;
    case 'invest': { const r = investInRegion(state); render(); toast(r.message, r.ok ? 'good' : 'warn'); break; }
    case 'forum': { const r = holdRegionalForum(state); render(); toast(r.message, r.ok ? 'good' : 'warn'); break; }
    case 'resilience': { const r = strengthenResilience(state); render(); toast(r.message, r.ok ? 'good' : 'warn'); break; }
    case 'save': {
      const ok = saveGame(state);
      toast(ok ? 'ゲームをこのブラウザに保存しました。' : '保存に失敗しました。ブラウザのストレージ設定を確認してください。', ok ? 'good' : 'warn');
      break;
    }
    case 'help': showModal('NATION FRONTIER — 操作ガイド', `<p>日本を舞台にした国家・都市・産業シミュレーションの試作版です。</p><ul><li><strong>国家戦略：</strong>地図上の都道府県を選び、重点投資や地域協議会を実行します。</li><li><strong>都市開発：</strong>建設メニューを選び、都市ゲートにつながる道路・鉄道網に接続する区画へ施設を配置します。地域ごとに都市データは別々に保存されます。</li><li><strong>経済：</strong>税率を調整します。高税率は収入を増やしますが支持率に影響します。</li><li><strong>研究：</strong>RPと政策行動力を使って技術を解禁します。</li><li><strong>外交・防衛：</strong>協定や国土強靱化により国家能力を高めます。</li><li><strong>月を進める：</strong>収支・人口・研究・地域支持に加え、各都市の電力・物流・工場生産が更新され、行動力が4に回復します。</li></ul><p>ゲームデータはこのブラウザのローカルストレージに保存できます。数値は試作用のゲームバランス値で、現実の統計や政策評価ではありません。</p>`); break;
    case 'close-modal': document.querySelector('#modalBackdrop').classList.add('hidden'); break;
    case 'reset': showModal('新しいゲームを開始しますか？', '<p>現在の進行状況を破棄して、2026年4月の初期状態に戻します。続ける前にセーブしてください。</p>', '<button class="button ghost" data-action="close-modal">キャンセル</button><button class="button danger" data-action="confirm-reset">新しく始める</button>'); break;
    case 'confirm-reset': state = createNewGame(); document.querySelector('#modalBackdrop').classList.add('hidden'); render(); toast('新しいゲームを開始しました。'); break;
    case 'home': state.activeView = 'strategy'; render(); break;
  }
}

function handleInput(event) {
  if (event.target.id === 'taxSlider') {
    setTaxRate(state, event.target.value);
    const label = document.querySelector('#taxValue');
    if (label) label.textContent = `${state.taxRate}%`;
    // Update only the tax preview and bar widths without rebuilding the range input.
    const stats = getNationalCityStats(state);
    const tradeBonus = state.partners.reduce((sum,p)=>sum+Math.max(0,p.relation-40)*.22,0) * stats.logisticsEfficiency;
    const income = Math.round((280 + stats.tax + stats.effectiveIndustry * .48 + tradeBonus) * state.taxRate / 12);
    const metric = document.querySelector('.kpi-card:nth-child(3) strong');
    if (metric) metric.textContent = money(income);
    const values = [280, stats.tax, Math.round(stats.effectiveIndustry * .48), Math.round(tradeBonus)].map(v => Math.round(v * state.taxRate / 12));
    document.querySelectorAll('.bar-row').forEach((row, i) => {
      const fill = row.querySelector('.bar-fill');
      const value = row.querySelector('strong');
      if (fill) fill.style.width = `${Math.min(100, Math.max(2, values[i] / 3.8))}%`;
      if (value) value.textContent = `${fmt(values[i])}億`;
    });
  }
}

app.addEventListener('click', handleClick);
app.addEventListener('input', handleInput);
document.querySelector('#modalBackdrop').addEventListener('click', (event) => {
  if (event.target.id === 'modalBackdrop') event.currentTarget.classList.add('hidden');
});
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') document.querySelector('#modalBackdrop').classList.add('hidden');
  if (event.target.matches('input,textarea,select')) return;
  const keyViews = { '1':'strategy', '2':'city', '3':'economy', '4':'research', '5':'diplomacy', '6':'defense' };
  if (keyViews[event.key]) { state.activeView = keyViews[event.key]; render(); }
  if (event.key === 'Enter' && event.target.closest('.pref-marker')) selectPrefecture(event.target.closest('.pref-marker').dataset.pref);
});

render();
