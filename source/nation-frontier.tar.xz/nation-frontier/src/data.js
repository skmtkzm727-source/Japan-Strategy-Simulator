// Fictional game-balance data. Population/GDP values are gameplay parameters, not official statistics.
const rows = [
  ['北海道','北海道',780,132,510,44,7],
  ['青森','東北',750,258,125,32,4],['岩手','東北',752,305,120,35,5],['宮城','東北',730,345,230,55,6],['秋田','東北',704,294,95,30,4],['山形','東北',704,351,105,37,5],['福島','東北',687,390,180,48,7],
  ['茨城','関東',710,431,290,63,8],['栃木','関東',683,412,195,58,7],['群馬','関東',657,405,195,57,7],['埼玉','関東',654,444,520,60,5],['千葉','関東',724,468,430,62,8],['東京','関東',664,475,1400,95,3],['神奈川','関東',640,498,720,80,5],
  ['新潟','中部',624,355,210,50,7],['富山','中部',568,406,105,58,8],['石川','中部',540,402,115,56,6],['福井','中部',514,440,78,54,8],['山梨','中部',628,468,82,48,5],['長野','中部',594,430,205,58,8],['岐阜','中部',555,455,195,57,7],['静岡','中部',634,513,365,70,8],['愛知','中部',570,510,760,88,8],
  ['三重','近畿',520,538,175,60,8],['滋賀','近畿',485,465,145,58,7],['京都','近畿',462,482,270,73,5],['大阪','近畿',444,512,880,90,4],['兵庫','近畿',410,506,520,78,8],['奈良','近畿',470,538,125,47,4],['和歌山','近畿',446,565,90,44,8],
  ['鳥取','中国',356,480,55,35,5],['島根','中国',326,501,65,32,7],['岡山','中国',376,530,190,64,8],['広島','中国',326,550,280,75,8],['山口','中国',281,555,125,57,8],
  ['徳島','四国',401,601,75,45,6],['香川','四国',375,581,95,55,6],['愛媛','四国',336,607,135,52,8],['高知','四国',371,637,70,38,8],
  ['福岡','九州',215,556,510,82,6],['佐賀','九州',189,576,75,40,7],['長崎','九州',155,592,125,48,7],['熊本','九州',211,613,185,57,8],['大分','九州',250,594,115,48,8],['宮崎','九州',245,638,105,42,8],['鹿児島','九州',210,665,155,47,8],['沖縄','沖縄',70,680,145,52,5]
];

export const prefectures = rows.map(([name, region, x, y, population, industry, resource], i) => ({
  id: `p${i+1}`, name, region, x, y,
  population, // 10,000 people; game scale
  industry,   // 0-100 game index
  resource,   // 0-10 game index
  support: Math.max(48, Math.min(82, 57 + ((i * 7) % 23))),
  influence: Math.max(36, Math.min(74, 42 + ((i * 11) % 33))),
  owner: 'national'
}));

export const buildings = {
  road: { name: '道路', icon: '━━', cost: 12, upkeep: 1, network: 1, desc: '都市内の交通網をつなぐ基礎インフラ。' },
  rail: { name: '鉄道', icon: '═', cost: 28, upkeep: 2, network: 3.5, desc: '高容量の旅客・貨物輸送網。道路または鉄道に接続して敷設。', requires: 'high-speed-rail' },
  housing: { name: '住宅地', icon: '⌂', cost: 180, upkeep: 3, population: 1800, tax: 24, powerDemand: 1.5, freightDemand: 1.2, desc: '人口と税収を増やす。道路・鉄道ネットワークに接続して建設。' },
  factory: { name: '先端工場', icon: '▦', cost: 420, upkeep: 12, industry: 32, tax: 48, jobs: 140, powerDemand: 24, freightDemand: 18, desc: '工業生産と輸出を伸ばす。電力と物流容量が必要。' },
  station: { name: '交通ターミナル', icon: '▤', cost: 340, upkeep: 8, logistics: 24, tax: 18, jobs: 28, powerDemand: 4, freightDemand: 2, desc: '旅客・貨物の流れを改善する。道路・鉄道に接続。' },
  solar: { name: '太陽光発電', icon: '▧', cost: 260, upkeep: 4, power: 36, tax: 5, jobs: 8, desc: '電力供給を増やし、停電リスクを下げる。' },
  university: { name: '研究大学', icon: '⌬', cost: 520, upkeep: 14, research: 8, tax: 10, jobs: 65, powerDemand: 6, freightDemand: 1, desc: '毎月の研究力を増やす。' },
  park: { name: '公園', icon: '♧', cost: 90, upkeep: 2, support: 2, tax: 2, desc: '住環境と地域支持を改善する。' },
  port: { name: '港湾施設', icon: '⚓', cost: 460, upkeep: 11, logistics: 34, tax: 28, jobs: 42, powerDemand: 5, freightDemand: 3, desc: '広域物流と交易を強化する。海沿いの都市を想定した施設。', requires: 'ai-logistics' },
  warehouse: { name: '物流倉庫', icon: '▤', cost: 310, upkeep: 7, logistics: 42, tax: 12, jobs: 24, powerDemand: 3, freightDemand: 1, desc: '貨物の保管・仕分け能力を高め、物流容量を増やす。', requires: 'ai-logistics' },
  battery: { name: '大型蓄電所', icon: '▣', cost: 380, upkeep: 5, power: 22, tax: 4, jobs: 10, desc: '電力需給の余力を増やす。', requires: 'smart-grid' },
  airport: { name: '貨物空港', icon: '✈', cost: 620, upkeep: 18, logistics: 48, tax: 36, jobs: 58, powerDemand: 8, freightDemand: 4, desc: '高付加価値貨物の広域輸送を担う。', requires: 'ai-logistics' }
};

export const technologies = [
  { id: 'smart-grid', name: 'スマートグリッド', group: 'エネルギー', cost: 36, desc: '電力供給効率 +15%。再生可能電源の効果が上昇。', prereq: [] },
  { id: 'high-speed-rail', name: '次世代高速鉄道', group: '交通', cost: 48, desc: '交通ターミナルの物流効果 +30%。', prereq: [] },
  { id: 'robotics', name: '産業ロボティクス', group: '産業', cost: 62, desc: '先端工場の生産力 +25%。', prereq: ['smart-grid'] },
  { id: 'ai-logistics', name: 'AI物流最適化', group: 'デジタル', cost: 78, desc: '物流効率 +20%、維持費を軽減。', prereq: ['high-speed-rail'] },
  { id: 'fusion', name: '次世代核融合実証', group: 'エネルギー', cost: 125, desc: '近未来発電網を解禁。電力自給率を大幅に改善。', prereq: ['smart-grid','robotics'] },
  { id: 'autonomous-city', name: '自律型スマートシティ', group: '都市', cost: 145, desc: '住宅・公共施設の税収と支持率効果を強化。', prereq: ['ai-logistics','robotics'] }
];

export const foreignPartners = [
  { id: 'pacific', name: '太平洋共同圏', relation: 52, focus: '海運・エネルギー', detail: '海上物流と資源供給の協力枠組み。' },
  { id: 'east-asia', name: '東アジア産業連携', relation: 44, focus: '製造・部品', detail: '部品調達と共同研究を進める経済圏。' },
  { id: 'north-america', name: '北米技術協定', relation: 61, focus: 'AI・先端技術', detail: 'AI・半導体・研究者交流の協定。' },
  { id: 'europe', name: '欧州グリーン連合', relation: 48, focus: '環境・電力', detail: '脱炭素技術と電力網の共同開発。' }
];

export const emptyCity = () => ({
  width: 13,
  height: 9,
  tiles: Array.from({ length: 13 * 9 }, () => null)
});

export const initialCity = () => {
  const width = 13, height = 9;
  const tiles = Array.from({ length: width * height }, () => null);
  // Starter road grid connects the north/south and east/west city gates.
  for (let x = 0; x < width; x++) {
    tiles[4 * width + x] = { type: 'road' };
    if (x % 3 === 1) tiles[2 * width + x] = { type: 'road' };
  }
  for (let y = 0; y < height; y++) tiles[y * width + 6] = { type: 'road' };
  tiles[3 * width + 4] = { type: 'housing' };
  tiles[5 * width + 8] = { type: 'factory' };
  tiles[3 * width + 8] = { type: 'station' };
  tiles[5 * width + 3] = { type: 'solar' };
  tiles[3 * width + 5] = { type: 'park' };
  return { width, height, tiles };
};
