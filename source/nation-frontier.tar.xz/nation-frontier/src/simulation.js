import { prefectures, buildings, technologies, foreignPartners, initialCity, emptyCity } from './data.js';

const SAVE_KEY = 'nation-frontier-save-v2';
const LEGACY_SAVE_KEY = 'nation-frontier-save-v1';

function blankCities() {
  return Object.fromEntries(prefectures.map(pref => [pref.id, emptyCity()]));
}

export function createNewGame() {
  const cities = blankCities();
  cities.p23 = initialCity();
  return {
    version: 2,
    date: { year: 2026, month: 4 },
    funds: 4850,
    gdp: 612.4,
    population: 11940,
    approval: 63,
    researchPoints: 28,
    defense: 54,
    readiness: 61,
    actionPoints: 4,
    taxRate: 12,
    selectedPrefecture: 'p23',
    activeView: 'strategy',
    selectedBuild: 'road',
    cities,
    prefectures: structuredClone(prefectures),
    technologies: [],
    partners: structuredClone(foreignPartners),
    events: [
      { month: '2026.04', title: '新年度の国家計画', text: '地域投資と次世代産業の育成を柱とする国家計画が始動しました。', kind: 'info' }
    ],
    lastMonthly: { income: 0, upkeep: 0, research: 0, production: 0, powerEfficiency: 1, logisticsEfficiency: 1 }
  };
}

function migrateSave(parsed) {
  if (!parsed || !Array.isArray(parsed.prefectures)) return null;
  if (!parsed.cities) {
    // v1 stored only one city. Preserve that city under its currently selected prefecture.
    const cities = blankCities();
    const key = parsed.selectedPrefecture || 'p23';
    if (parsed.city?.tiles) cities[key] = parsed.city;
    parsed.cities = cities;
  }
  for (const pref of parsed.prefectures) {
    if (!parsed.cities[pref.id]?.tiles) parsed.cities[pref.id] = emptyCity();
  }
  delete parsed.city;
  parsed.version = 2;
  parsed.lastMonthly ||= { income: 0, upkeep: 0, research: 0, production: 0, powerEfficiency: 1, logisticsEfficiency: 1 };
  parsed.events ||= [];
  return parsed;
}

export function loadGame() {
  try {
    const raw = localStorage.getItem(SAVE_KEY) || localStorage.getItem(LEGACY_SAVE_KEY);
    if (!raw) return null;
    const parsed = migrateSave(JSON.parse(raw));
    if (!parsed || !parsed.cities) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function saveGame(state) {
  try {
    localStorage.setItem(SAVE_KEY, JSON.stringify(state));
    return true;
  } catch {
    return false;
  }
}

export function getSelectedPrefecture(state) {
  return state.prefectures.find(p => p.id === state.selectedPrefecture) ?? state.prefectures[22];
}

export function getSelectedCity(state) {
  if (!state.cities) state.cities = blankCities();
  const key = state.selectedPrefecture || 'p23';
  if (!state.cities[key]?.tiles) state.cities[key] = emptyCity();
  return state.cities[key];
}

function roadNetwork(city) {
  const { width, height, tiles } = city;
  const transport = new Set();
  const queue = [];
  for (let i = 0; i < tiles.length; i++) {
    if (!['road', 'rail'].includes(tiles[i]?.type)) continue;
    const x = i % width, y = Math.floor(i / width);
    if (x === 0 || y === 0 || x === width - 1 || y === height - 1) {
      transport.add(i);
      queue.push(i);
    }
  }
  // Only transport tiles connected to at least one city gate are active.
  for (let cursor = 0; cursor < queue.length; cursor++) {
    const i = queue[cursor], x = i % width, y = Math.floor(i / width);
    for (const [nx, ny] of [[x - 1, y], [x + 1, y], [x, y - 1], [x, y + 1]]) {
      if (nx < 0 || nx >= width || ny < 0 || ny >= height) continue;
      const ni = ny * width + nx;
      if (!transport.has(ni) && ['road', 'rail'].includes(tiles[ni]?.type)) {
        transport.add(ni);
        queue.push(ni);
      }
    }
  }
  return transport;
}

function isAdjacentToNetwork(city, index, network) {
  const { width, height, tiles } = city;
  const x = index % width, y = Math.floor(index / width);
  return [[x - 1, y], [x + 1, y], [x, y - 1], [x, y + 1]]
    .filter(([nx, ny]) => nx >= 0 && nx < width && ny >= 0 && ny < height)
    .some(([nx, ny]) => network.has(ny * width + nx) && ['road', 'rail'].includes(tiles[ny * width + nx]?.type));
}

export function getCityStats(state, city = getSelectedCity(state)) {
  const totals = {
    population: 0, industry: 0, effectiveIndustry: 0, logistics: 0, power: 0,
    powerDemand: 0, powerEfficiency: 1, logisticsDemand: 0, logisticsCapacity: 0,
    logisticsEfficiency: 1, research: 0, tax: 0, upkeep: 0, count: 0,
    roads: 0, rails: 0, transportTiles: 0, jobs: 0, connectedFacilities: 0, disconnectedFacilities: 0,
    factories: 0, housing: 0, freightMoved: 0
  };
  const network = roadNetwork(city);
  for (const i of network) {
    if (city.tiles[i]?.type === 'road') totals.roads++;
    if (city.tiles[i]?.type === 'rail') totals.rails++;
  }

  let connectedIndustry = 0;
  for (let i = 0; i < city.tiles.length; i++) {
    const tile = city.tiles[i];
    if (!tile) continue;
    const b = buildings[tile.type];
    if (!b) continue;
    totals.count++;
    if (tile.type === 'road' || tile.type === 'rail') {
      totals.transportTiles++;
      continue;
    }
    const connected = isAdjacentToNetwork(city, i, network);
    if (connected) totals.connectedFacilities++;
    else totals.disconnectedFacilities++;
    const activeRatio = connected ? 1 : 0;
    totals.population += (b.population || 0) * activeRatio;
    totals.industry += b.industry || 0;
    totals.logistics += b.logistics || 0;
    totals.power += (b.power || 0) * activeRatio;
    totals.powerDemand += (b.powerDemand || 0) * activeRatio;
    totals.logisticsDemand += (b.freightDemand || 0) * activeRatio;
    totals.research += (b.research || 0) * activeRatio;
    totals.tax += (b.tax || 0) * activeRatio;
    totals.upkeep += b.upkeep || 0;
    totals.jobs += (b.jobs || 0) * activeRatio;
    if (tile.type === 'factory') {
      totals.factories++;
      if (connected) connectedIndustry += b.industry || 0;
    }
    if (tile.type === 'housing' && connected) totals.housing++;
  }

  totals.logisticsCapacity = totals.logistics + totals.roads * 0.8 + totals.rails * 2.8;
  totals.powerEfficiency = totals.powerDemand > 0 ? Math.min(1, totals.power / totals.powerDemand) : 1;
  totals.logisticsEfficiency = totals.logisticsDemand > 0 ? Math.min(1, totals.logisticsCapacity / totals.logisticsDemand) : 1;
  const builtFacilities = Math.max(1, totals.count - totals.transportTiles);
  const connectivity = totals.count > 0 ? totals.connectedFacilities / builtFacilities : 1;
  totals.effectiveIndustry = connectedIndustry * totals.powerEfficiency * totals.logisticsEfficiency * connectivity;
  totals.freightMoved = Math.round(totals.logisticsDemand * totals.logisticsEfficiency);
  totals.powerSurplus = totals.power - totals.powerDemand;
  return totals;
}

export function getNationalCityStats(state) {
  const sumKeys = ['population','industry','effectiveIndustry','logistics','power','powerDemand','logisticsDemand','logisticsCapacity','research','tax','upkeep','count','roads','rails','transportTiles','jobs','connectedFacilities','disconnectedFacilities','factories','housing','freightMoved'];
  const total = Object.fromEntries(sumKeys.map(key => [key, 0]));
  let powerWeighted = 0, logisticsWeighted = 0, industryWeight = 0, freightWeight = 0;
  for (const city of Object.values(state.cities || {})) {
    const stats = getCityStats(state, city);
    for (const key of sumKeys) total[key] += stats[key] || 0;
    powerWeighted += stats.powerEfficiency * stats.powerDemand;
    logisticsWeighted += stats.logisticsEfficiency * stats.logisticsDemand;
    industryWeight += stats.powerDemand;
    freightWeight += stats.logisticsDemand;
  }
  total.powerEfficiency = industryWeight ? powerWeighted / industryWeight : 1;
  total.logisticsEfficiency = freightWeight ? logisticsWeighted / freightWeight : 1;
  total.powerSurplus = total.power - total.powerDemand;
  return total;
}

function addEvent(state, title, text, kind = 'info') {
  state.events.unshift({ month: `${state.date.year}.${String(state.date.month).padStart(2, '0')}`, title, text, kind });
  state.events = state.events.slice(0, 10);
}

function spendActionPoint(state) {
  if (state.actionPoints < 1) return false;
  state.actionPoints -= 1;
  return true;
}

export function investInRegion(state) {
  const pref = getSelectedPrefecture(state), cost = 260;
  if (state.actionPoints < 1) return { ok: false, message: '今月の政策行動力がありません。月を進めてください。' };
  if (state.funds < cost) return { ok: false, message: '投資予算が不足しています。' };
  spendActionPoint(state); state.funds -= cost;
  pref.support = Math.min(100, pref.support + 8);
  pref.influence = Math.min(100, pref.influence + 6);
  state.gdp = +(state.gdp + 0.35).toFixed(2);
  addEvent(state, `${pref.name}への重点投資`, `${pref.name}に${cost}億円を投資。地域支持と経済基盤が改善しました。`, 'good');
  return { ok: true, message: `${pref.name}に重点投資しました。` };
}

export function holdRegionalForum(state) {
  const pref = getSelectedPrefecture(state), cost = 90;
  if (state.actionPoints < 1) return { ok: false, message: '今月の政策行動力がありません。' };
  if (state.funds < cost) return { ok: false, message: '予算が不足しています。' };
  spendActionPoint(state); state.funds -= cost;
  pref.support = Math.min(100, pref.support + 5);
  pref.influence = Math.min(100, pref.influence + 10);
  state.approval = Math.min(100, state.approval + 1);
  addEvent(state, `${pref.name}地域協議会`, '自治体・企業・住民との協議がまとまり、政策への信頼が高まりました。', 'good');
  return { ok: true, message: `${pref.name}で地域協議会を開催しました。` };
}

export function placeBuilding(state, index, type) {
  const city = getSelectedCity(state);
  const { width, height, tiles } = city;
  if (!Number.isInteger(index) || index < 0 || index >= width * height) return { ok: false, message: '配置位置が正しくありません。' };
  const definition = buildings[type];
  if (!definition) return { ok: false, message: 'その施設は建設できません。' };
  if (definition.requires && !state.technologies.includes(definition.requires)) return { ok: false, message: 'この施設には先行技術の研究が必要です。' };
  const current = tiles[index];
  if (current) return { ok: false, message: 'この区画には既に施設があります。撤去してから建設してください。' };
  const network = roadNetwork(city);
  if (type === 'road' || type === 'rail') {
    const x = index % width, y = Math.floor(index / width);
    const boundary = x === 0 || y === 0 || x === width - 1 || y === height - 1;
    if (network.size === 0 && !boundary) return { ok: false, message: '最初の道路・鉄道は都市ゲート（外周）から敷設してください。' };
    if (network.size > 0 && !isAdjacentToNetwork(city, index, network) && !boundary) return { ok: false, message: '既存の交通網に接続するか、外周の都市ゲートから敷設してください。' };
  } else if (!isAdjacentToNetwork(city, index, network)) {
    return { ok: false, message: '施設は都市ゲートにつながった道路・鉄道に隣接する区画へ配置してください。' };
  }
  if (state.funds < definition.cost) return { ok: false, message: '建設予算が不足しています。' };
  state.funds -= definition.cost;
  tiles[index] = { type };
  addEvent(state, `${getSelectedPrefecture(state).name}で建設`, `${definition.name}を${definition.cost}億円で整備しました。`, 'info');
  return { ok: true, message: `${definition.name}を建設しました。` };
}

export function demolishTile(state, index) {
  const city = getSelectedCity(state);
  const tile = city.tiles[index];
  if (!tile) return { ok: false, message: 'この区画には建物がありません。' };
  const previous = tile;
  city.tiles[index] = null;
  if (['road','rail'].includes(previous.type)) {
    const stats = getCityStats(state, city);
    if (stats.disconnectedFacilities > 0) {
      city.tiles[index] = previous;
      return { ok: false, message: 'この交通網を撤去すると施設が孤立します。先に施設を撤去してください。' };
    }
  }
  state.funds += Math.round((buildings[previous.type]?.cost || 0) * 0.2);
  addEvent(state, `${getSelectedPrefecture(state).name}で施設撤去`, `${buildings[previous.type]?.name || '施設'}を撤去しました。`, 'warn');
  return { ok: true, message: '施設を撤去しました（建設費の20%を回収）。' };
}

export function setTaxRate(state, value) {
  state.taxRate = Math.max(8, Math.min(18, Number(value) || 12));
}

export function startResearch(state, technologyId) {
  const tech = technologies.find(t => t.id === technologyId);
  if (!tech) return { ok: false, message: '研究項目が見つかりません。' };
  if (state.technologies.includes(technologyId)) return { ok: false, message: 'この技術は既に完成しています。' };
  if (!tech.prereq.every(id => state.technologies.includes(id))) return { ok: false, message: '先行研究が必要です。' };
  if (state.actionPoints < 1) return { ok: false, message: '今月の政策行動力がありません。' };
  if (state.researchPoints < tech.cost) return { ok: false, message: '研究ポイントが不足しています。' };
  spendActionPoint(state); state.researchPoints -= tech.cost; state.technologies.push(technologyId);
  addEvent(state, `研究完了：${tech.name}`, tech.desc, 'good');
  return { ok: true, message: `${tech.name}の研究が完了しました。` };
}

export function signAgreement(state, partnerId) {
  const partner = state.partners.find(p => p.id === partnerId);
  if (!partner) return { ok: false, message: '協定相手が見つかりません。' };
  if (state.actionPoints < 1) return { ok: false, message: '今月の外交行動力がありません。' };
  const cost = 420;
  if (state.funds < cost) return { ok: false, message: '協定準備費が不足しています。' };
  spendActionPoint(state); state.funds -= cost; partner.relation = Math.min(100, partner.relation + 18);
  addEvent(state, `${partner.name}と協力協定`, `${partner.focus}分野の協力協定を締結しました。交易収入と物流が改善します。`, 'good');
  return { ok: true, message: `${partner.name}と協力協定を締結しました。` };
}

export function strengthenResilience(state) {
  const cost = 340;
  if (state.actionPoints < 1) return { ok: false, message: '今月の行動力がありません。' };
  if (state.funds < cost) return { ok: false, message: '予算が不足しています。' };
  spendActionPoint(state); state.funds -= cost;
  state.defense = Math.min(100, state.defense + 4); state.readiness = Math.min(100, state.readiness + 8);
  addEvent(state, '国土強靱化・防衛演習', '重要インフラの点検と広域対応訓練を実施。防衛・危機対応能力が向上しました。', 'good');
  return { ok: true, message: '国土強靱化計画を実施しました。' };
}

export function advanceMonth(state) {
  const stats = getNationalCityStats(state);
  const tradeBase = state.partners.reduce((sum, p) => sum + Math.max(0, p.relation - 40) * 0.22, 0);
  const tradeBonus = tradeBase * stats.logisticsEfficiency;
  const taxFactor = state.taxRate / 12;
  const industryBonus = stats.effectiveIndustry * 0.48;
  const income = Math.round((280 + stats.tax + industryBonus + tradeBonus) * taxFactor);
  const upkeep = Math.round(88 + stats.upkeep + state.defense * 0.72);
  const net = income - upkeep;
  state.funds += net;
  const researchGain = Math.round((18 + stats.research) * (0.75 + 0.25 * stats.powerEfficiency));
  state.lastMonthly = {
    income, upkeep, research: researchGain,
    production: Math.round(stats.effectiveIndustry),
    powerEfficiency: stats.powerEfficiency,
    logisticsEfficiency: stats.logisticsEfficiency
  };
  state.researchPoints += researchGain;
  state.gdp = +(state.gdp + 0.22 + stats.effectiveIndustry * 0.003 + tradeBonus * 0.003).toFixed(2);
  state.population = Math.round(state.population + 1 + stats.population / 1000);
  const taxPressure = state.taxRate > 15 ? 1 : state.taxRate < 10 ? -0.3 : 0;
  const servicePressure = stats.powerEfficiency < 0.7 || stats.logisticsEfficiency < 0.55 ? 0.45 : 0;
  state.approval = Math.max(15, Math.min(100, state.approval + (net > 0 ? 0.3 : -0.5) - taxPressure - servicePressure));

  for (const pref of state.prefectures) {
    const drift = (state.approval - pref.support) * 0.012;
    pref.support = Math.max(10, Math.min(100, +(pref.support + drift).toFixed(1)));
    pref.influence = Math.max(0, Math.min(100, +(pref.influence + (pref.support - 55) * 0.004).toFixed(1)));
  }
  state.partners.forEach(p => {
    if (p.relation > 75) p.relation = Math.min(100, p.relation + 0.2);
    else if (p.relation < 35) p.relation = Math.max(0, p.relation - 0.15);
  });
  state.date.month += 1;
  if (state.date.month > 12) { state.date.month = 1; state.date.year += 1; }
  state.actionPoints = 4;

  let title = '月次経済レポート';
  let text = `収入${income}億円、維持費${upkeep}億円。差引 ${net >= 0 ? '+' : ''}${net}億円。実効生産指数 ${Math.round(stats.effectiveIndustry)}、電力充足 ${Math.round(stats.powerEfficiency*100)}%、物流充足 ${Math.round(stats.logisticsEfficiency*100)}%。`;
  let kind = net >= 0 ? 'good' : 'warn';
  const roll = Math.random();
  if (roll < 0.08) {
    const pref = state.prefectures[Math.floor(Math.random() * state.prefectures.length)];
    pref.support = Math.max(10, pref.support - 4);
    title = `${pref.name}で地域課題が発生`;
    text = 'インフラ更新の遅れが報告されました。次の政策投資で支持を回復できます。';
    kind = 'warn';
  } else if (roll > 0.93) {
    state.gdp = +(state.gdp + 0.5).toFixed(2);
    title = '国内産業に追い風';
    text = '輸出需要の増加により、国内総生産が追加で成長しました。';
    kind = 'good';
  }
  addEvent(state, title, text, kind);
  return { ok: true, income, upkeep, net, research: researchGain, production: stats.effectiveIndustry, powerEfficiency: stats.powerEfficiency, logisticsEfficiency: stats.logisticsEfficiency, event: { title, text, kind } };
}
