# Simutrans ソースコード利用方針

## 現在の状態

この初期プロトタイプには Simutrans のソースコードをまだコピー・移植していません。都市タイル、建設費、施設維持費、交通容量の初期モデルは、このプロジェクト用に独立して作成した簡易実装です。

## 参照元

- Repository: https://github.com/simutrans/simutrans
- License: Artistic License 1.0
- Official license file: https://github.com/simutrans/simutrans/blob/master/LICENSE.txt
- Simutrans README states that the source is under Artistic License 1.0 and that paksets have separate licenses.

## 利用時に必ず行うこと

Simutrans 由来のコードを本プロジェクトへコピー・改変・同梱する場合は、対象ファイルごとに出自を記録し、元の著作権表示と免責を保持する。変更したファイルには、何をいつ変更したかを目立つ形で記す。配布形態に応じて Artistic License 1.0 の条件を満たし、ライセンス全文・変更点・入手元・標準版との差分を明示する。

特に Artistic License 1.0 は、改変版の配布や実行ファイルの配布について複数の条件を置いている。条文3・4の選択肢、条文5の料金・同梱条件を確認せずに、一般的なMIT/BSDのように扱ってはならない。商用配布を検討する場合、ゲーム本体とSimutrans由来コンポーネントの分離、変更ソースの公開要否、標準版との併記、権利者との個別合意を含め、配布前に法務確認する。

## 初期版での判断

現段階では Simutrans の巨大なC++コードベースをWebへ丸ごと移植しない。まずはゲームに必要な物流・経路探索・貨物需要を独立モジュールとして設計する。Simutransコードの再利用が技術的・ライセンス的に有効と判断できた場合のみ、特定ファイルを選定し、次の情報を追加する。

- 元リポジトリの commit SHA と元ファイルパス
- ファイルごとの元著作権表示
- コピー日・変更日・変更内容
- 適用した Artistic License 1.0 の配布条件
- 対応する標準版ソース／実行ファイルの入手方法
- pakset・画像・音声・フォント等の個別ライセンス確認結果

Simutrans本体のライセンスは、paksetや追加素材のライセンスを一括して許諾するものではない。追加素材は必ず別途確認する。
