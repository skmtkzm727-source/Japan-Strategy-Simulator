import test from 'node:test';
import assert from 'node:assert/strict';
import {
  createNewGame, getSelectedCity, getCityStats, getNationalCityStats,
  placeBuilding, demolishTile, advanceMonth, startResearch, loadGame, saveGame
} from '../src/simulation.js';
import { prefectures } from '../src/data.js';

function memoryStorage() {
  const store = new Map();
  return {
    getItem: key => store.has(key) ? store.get(key) : null,
    setItem: (key, value) => store.set(key, String(value)),
    removeItem: key => store.delete(key),
    clear: () => store.clear()
  };
}

test('new game has 47 independently managed prefecture cities', () => {
  const state = createNewGame();
  assert.equal(state.prefectures.length, 47);
  assert.equal(Object.keys(state.cities).length, 47);
  assert.equal(state.cities.p23.tiles.filter(Boolean).length > 0, true);
  assert.equal(state.cities.p1.tiles.every(tile => tile === null), true);
});

test('starter Aichi city has a working connected power and logistics network', () => {
  const state = createNewGame();
  const stats = getCityStats(state);
  assert.ok(stats.roads > 0);
  assert.ok(stats.power > stats.powerDemand);
  assert.equal(stats.powerEfficiency, 1);
  assert.equal(stats.logisticsEfficiency, 1);
  assert.ok(stats.effectiveIndustry > 0);
  assert.equal(stats.disconnectedFacilities, 0);
});

test('building in one prefecture does not modify another prefecture city', () => {
  const state = createNewGame();
  const aichiBefore = JSON.stringify(state.cities.p23);
  state.selectedPrefecture = 'p1';
  const city = getSelectedCity(state);
  assert.equal(city.tiles.every(tile => tile === null), true);
  assert.equal(placeBuilding(state, 65, 'factory').ok, false, 'factory cannot be placed without a connected network');
  assert.equal(JSON.stringify(state.cities.p23), aichiBefore);
});

test('city gate roads can be extended and used to connect a new facility', () => {
  const state = createNewGame();
  state.selectedPrefecture = 'p1';
  assert.equal(placeBuilding(state, 0, 'road').ok, true);
  assert.equal(placeBuilding(state, 1, 'road').ok, true);
  assert.equal(placeBuilding(state, 14, 'housing').ok, true);
  const stats = getCityStats(state);
  assert.equal(stats.connectedFacilities, 1);
  assert.equal(stats.population, 1800);
});

test('rail, battery and logistics buildings require technologies', () => {
  const state = createNewGame();
  state.selectedPrefecture = 'p1';
  placeBuilding(state, 0, 'road');
  assert.equal(placeBuilding(state, 1, 'rail').ok, false);
  assert.equal(placeBuilding(state, 1, 'battery').ok, false);
  state.technologies.push('high-speed-rail', 'smart-grid', 'ai-logistics');
  assert.equal(placeBuilding(state, 1, 'rail').ok, true);
});

test('demolition prevents transport links from isolating facilities', () => {
  const state = createNewGame();
  state.selectedPrefecture = 'p1';
  assert.equal(placeBuilding(state, 0, 'road').ok, true);  // city gate (0,0)
  assert.equal(placeBuilding(state, 1, 'road').ok, true);  // extends inward
  assert.equal(placeBuilding(state, 14, 'housing').ok, true); // adjacent to tile 1
  const result = demolishTile(state, 1);
  assert.equal(result.ok, false);
  assert.match(result.message, /孤立/);
  assert.equal(getCityStats(state).disconnectedFacilities, 0);
});

test('factory output stops when its connected power supply is removed', () => {
  const state = createNewGame();
  const city = getSelectedCity(state);
  const solarIndex = city.tiles.findIndex(tile => tile?.type === 'solar');
  assert.ok(solarIndex >= 0);
  const before = getCityStats(state);
  assert.ok(before.effectiveIndustry > 0);
  assert.equal(demolishTile(state, solarIndex).ok, true);
  const after = getCityStats(state);
  assert.equal(after.powerEfficiency, 0);
  assert.equal(after.effectiveIndustry, 0);
});

test('month settlement uses national city stats and refreshes monthly action points', () => {
  const state = createNewGame();
  const initialFunds = state.funds;
  const result = advanceMonth(state);
  assert.equal(state.date.month, 5);
  assert.equal(state.actionPoints, 4);
  assert.equal(state.funds, initialFunds + result.net);
  assert.equal(state.lastMonthly.production, Math.round(result.production));
  assert.ok(result.powerEfficiency > 0.99);
});

test('save and load round-trip keeps separate city maps', () => {
  globalThis.localStorage = memoryStorage();
  const state = createNewGame();
  state.selectedPrefecture = 'p1';
  placeBuilding(state, 0, 'road');
  assert.equal(saveGame(state), true);
  const loaded = loadGame();
  assert.ok(loaded);
  assert.equal(loaded.version, 2);
  assert.equal(loaded.cities.p1.tiles[0].type, 'road');
  assert.equal(loaded.cities.p23.tiles.some(tile => tile?.type === 'factory'), true);
});

test('legacy v1 save migrates its single city into selected prefecture', () => {
  globalThis.localStorage = memoryStorage();
  const state = createNewGame();
  const legacy = { ...state, version: 1, city: state.cities.p23 };
  delete legacy.cities;
  globalThis.localStorage.setItem('nation-frontier-save-v1', JSON.stringify(legacy));
  const loaded = loadGame();
  assert.equal(loaded.version, 2);
  assert.ok(loaded.cities.p23.tiles.some(tile => tile?.type === 'factory'));
  assert.equal(loaded.cities.p1.tiles.every(tile => tile === null), true);
});

test('research unlocks high capacity construction', () => {
  const state = createNewGame();
  state.actionPoints = 4;
  state.researchPoints = 200;
  assert.equal(startResearch(state, 'high-speed-rail').ok, true);
  state.selectedPrefecture = 'p1';
  placeBuilding(state, 0, 'road');
  assert.equal(placeBuilding(state, 1, 'rail').ok, true);
});
